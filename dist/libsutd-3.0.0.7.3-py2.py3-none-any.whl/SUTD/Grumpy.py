"""Just why? :("""

def __init__(self):
    grumpy_tomb = """
                    _  /)
                    mo / )
                    |/)\)
                    /\_
                    \__|=
                    (    )
                    __)(__
            _____/      \\_____
            |  _     ___   _   ||
            | | \     |   | \  ||
            | |  |    |   |  | ||
            | |_/     |   |_/  ||
            | | \     |   |    ||
            | |  \    |   |    ||
            | |   \. _|_. | .  ||
            |                  ||
            |      GRUMPY      ||
            |                  ||
    *       | *   **    * **   |**      **
    \))ejm97/.,(//,,..,,\||(,,.,\\,.((//"""
    print(grumpy_tomb)

def meow(self):
    """makes the cat meow"""
    grumpy_dead = "you disgusting fuckhead"
    raise Exception(grumpy_dead)