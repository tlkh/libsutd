"""
Part and parcel of daily life?
"""

def projector()
  switch_on = "Nope. Please call tech support"
  raise Exception(switch_on)

def air_con(temp)
  if temp > 25:
    print("TURN IT DOWN AND SAVE POWER")
   else:
    print("Please note it is centrally controlled and it will be set at 21 degrees") 
