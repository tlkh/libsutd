libSUTD
=======================

Singapore University of Technical Difficulties
World's best design and tech school needs the world's most rad Python library.
RIP Grumpy

