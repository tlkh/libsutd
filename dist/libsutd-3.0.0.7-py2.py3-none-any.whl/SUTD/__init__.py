"""
Better World By Design. We try.
"""