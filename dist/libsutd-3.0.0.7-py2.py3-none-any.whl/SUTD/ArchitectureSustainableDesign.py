"""why the fuck would anyone need to import ASD anyway"""

def sleep():
    asd_no_sleep = "But in ASD nobody sleeps"
    raise Exception(asd_no_sleep)